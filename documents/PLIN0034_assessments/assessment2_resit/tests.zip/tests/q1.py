from otter.test_files import test_case

OK_FORMAT = False

name = "q1"
points = 10

@test_case(points=5, hidden=False)
def test_conllu_reader_basic(read_conllu_file):
    sentences = read_conllu_file('data/en_ewt-ud-dev.conllu')
    assert len(sentences) == 2001
    s = sentences[0]
    words = [x[0] for x in s]
    words_expected = ['From', 'the', 'AP', 'comes', 'this', 'story', ':']
    assert words == words_expected
    tags = [x[1] for x in s]
    tags_expected = ['ADP', 'DET', 'PROPN', 'VERB', 'DET', 'NOUN', 'PUNCT']
    assert tags == tags_expected
    s = sentences[-1]
    words = [x[0] for x in s]
    words_expected = ['Also', ',', 'they', 'have', 'great', 'customer', 'service', 'and', 'a', 'very', 'knowledgeable', 'staff']
    assert words == words_expected
    tags = [x[1] for x in s]
    tags_expected = ['ADV', 'PUNCT', 'PRON', 'VERB', 'ADJ', 'NOUN', 'NOUN', 'CCONJ', 'DET', 'ADV', 'ADJ', 'NOUN']
    assert tags == tags_expected

@test_case(points=1, hidden=True)
def test_conllu_reader_deps(read_conllu_file):
    sentences = read_conllu_file('data/en_ewt-ud-dev.conllu')
    s = sentences[0]
    deps = [int(d) for (w, p, d, l) in s]
    deps_expected = [3, 3, 4, 0, 6, 4, 4]
    assert deps == deps_expected

@test_case(points=1, hidden=True)
def test_conllu_reader_deps_int(read_conllu_file):
    sentences = read_conllu_file('data/en_ewt-ud-dev.conllu')
    s = sentences[0]
    deps = [d for (w, p, d, l) in s]
    deps_expected = [3, 3, 4, 0, 6, 4, 4]
    assert deps == deps_expected

@test_case(points=1, hidden=True)
def test_conllu_reader_lemmas(read_conllu_file):
    sentences = read_conllu_file('data/en_ewt-ud-dev.conllu')
    s = sentences[0]
    lemmas = [x[3] for x in s]
    lemmas_expected = ['from', 'the', 'AP', 'come', 'this', 'story', ':']
    assert lemmas == lemmas_expected

@test_case(points=1, hidden=True)
def test_conllu_reader_len_train_file(read_conllu_file):
    sentences = read_conllu_file('data/en_ewt-ud-train.conllu')
    assert len(sentences) == 12544

@test_case(points=1, hidden=True)
def test_conllu_reader_len_train_file_content(read_conllu_file):
    sentences = read_conllu_file('data/en_ewt-ud-train.conllu')
    words = []
    for s in sentences:
        words.extend([w for (w, p, d, l) in s])
    assert len(words) == 204579

