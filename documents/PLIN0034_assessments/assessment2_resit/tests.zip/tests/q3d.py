from otter.test_files import test_case

OK_FORMAT = False

name = "q3d"
points = 12.5

@test_case(points=4, hidden=False)
def test_dependency_parser_basic(dependency_parse):
    s = [('The', 'DET', -1), ('dog', 'NOUN', -1), ('ate', 'VERB', -1), ('my', 'DET', -1), ('homework', 'NOUN', -1), ('.', 'PUNCT', -1)]
    parse = dependency_parse(s)
    assert len(parse) == 6
    assert isinstance(parse[0], tuple) == True
    assert len(parse[0]) == 2
    assert [d for (d, h) in parse] == [1, 2, 3, 4, 5, 6]

@test_case(points=2.5, hidden=True)
def test_dependency_parser_single_sent(dependency_parse):
    s = [('My', 'DET', -1), ('dog', 'NOUN', -1), ('ate', 'VERB', -1), ('the', 'DET', -1), ('homework', 'NOUN', -1), ('assignment', 'NOUN', -1), ('.', 'PUNCT', -1)]
    parse = dependency_parse(s)
    expected_parse = [(1, 2), (2, 0), (3, 2), (4, 6), (5, 6), (6, 3), (7, 2)]
    assert parse == expected_parse

@test_case(points=6, hidden=True)
def test_dependency_parser_test_data(dependency_parse, read_conllu_file):
    test_sentences = read_conllu_file('data/en_ewt-ud-test.conllu')
    test_parses = []
    for sentence in test_sentences:
        test_parses.append(dependency_parse(sentence))
    correct = 0
    count = 0
    for (sentence, parse_tree) in zip(test_sentences, test_parses):
        for (word, deps) in zip(sentence, parse_tree):
            count += 1
            if int(word[2]) == deps[1]:
                correct += 1
    assert correct / count > 0.65

