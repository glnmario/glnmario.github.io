from otter.test_files import test_case

OK_FORMAT = False

name = "q3a"
points = 14

@test_case(points=14, hidden=False)
def test_feature_extractor_basic(extract_features):
    stack1 = [(0, 'ROOT', '_'), (1, 'The', 'DET')]
    input1 = [(2, 'dog', 'NOUN'), (3, 'ate', 'VERB'), (4, 'my', 'DET'), (5, 'homework', 'NOUN')]
    config1 = {'stack': stack1, 'input': input1}
    features_raw = extract_features(config1)
    features_expected = {'input_0_form': 'dog', 'input_0_pos': 'NOUN', 'input_1_form': 'ate', 'input_1_pos': 'VERB', 'input_2_pos': 'DET', 'input_3_pos': 'NOUN', 'stack_0_form': 'The', 'stack_0_pos': 'DET', 'stack_1_pos': '_', 'stack_input_distance': 1}
    for f in features_expected:
        assert features_raw[f] == features_expected[f]
    stack2 = [(0, 'ROOT', '_')]
    input2 = [(1, 'The', 'DET'), (2, 'cat', 'NOUN')]
    config2 = {'stack': stack2, 'input': input2}
    features_raw = extract_features(config2)
    features_expected = {'input_0_form': 'The', 'input_0_pos': 'DET', 'input_1_form': 'cat', 'input_1_pos': 'NOUN', 'input_2_pos': 'N/A', 'input_3_pos': 'N/A', 'stack_0_form': 'ROOT', 'stack_0_pos': '_', 'stack_1_pos': 'N/A', 'stack_input_distance': 1}
    for f in features_expected:
        assert features_raw[f] == features_expected[f]

