from otter.test_files import test_case

OK_FORMAT = False

name = "q2b"
points = 20

@test_case(points=10, hidden=False)
def test_bracket_parser_basic(bracket_parser):
    deps1 = bracket_parser('()')
    assert set(deps1) == set([(1, 2), (2, 0)])
    deps2 = bracket_parser('(')
    assert deps2 == 'not parseable'

@test_case(points=2.5, hidden=True)
def test_bracket_parser_xx(bracket_parser):
    deps = bracket_parser('()()')
    assert set(deps) == set([(1, 2), (2, 0), (3, 4), (4, 0)])

@test_case(points=2.5, hidden=True)
def test_bracket_parser_bxb(bracket_parser):
    deps = bracket_parser('(())')
    assert set(deps) == set([(2, 3), (1, 4), (3, 4), (4, 0)])

@test_case(points=2.5, hidden=True)
def test_bracket_parser_bbxxxxbb(bracket_parser):
    deps = bracket_parser('((()()()()))')
    assert set(deps) == set([(3, 4), (5, 6), (4, 6), (7, 8), (6, 8), (9, 10), (8, 10), (2, 11), (10, 11), (1, 12), (11, 12), (12, 0)])

@test_case(points=2.5, hidden=True)
def test_bracket_parser_unparseable(bracket_parser):
    deps = bracket_parser('((()()()())')
    assert deps == 'not parseable'
    deps = bracket_parser('()(')
    assert deps == 'not parseable'
    deps = bracket_parser(')))')
    assert deps == 'not parseable'
    deps = bracket_parser(')()(')
    assert deps == 'not parseable'
    deps = bracket_parser('(((((((((()))))))))')
    assert deps == 'not parseable'
    deps = bracket_parser('(((((((((()))))))))))')
    assert deps == 'not parseable'
    deps = bracket_parser('(((((((((())))))))))))))))')
    assert deps == 'not parseable'

