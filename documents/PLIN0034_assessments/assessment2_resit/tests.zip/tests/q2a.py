from otter.test_files import test_case

OK_FORMAT = False

name = "q2a"
points = 17.5

@test_case(points=7.5, hidden=False)
def test_pen_and_paper_basic(input_initial, input_iteration1, input_iteration2, input_iteration3, input_iteration4, input_iteration5, input_iteration6, dependencies_iteration1, dependencies_iteration2, dependencies_iteration3, dependencies_iteration4, dependencies_iteration5, dependencies_iteration6, stack_intial, stack_iteration1, stack_iteration2, stack_iteration3, stack_iteration4, stack_iteration5, stack_iteration6):
    assert len(input_initial) == 4
    assert len(input_iteration1) == 3
    assert len(input_iteration2) == 2
    assert len(input_iteration3) == 2
    assert len(input_iteration4) == 1
    assert len(input_iteration5) == 1
    assert len(input_iteration6) == 1
    assert type(input_initial[0]) == tuple
    assert len(input_initial[0]) == 2
    assert type(input_initial[0][0]) == int
    assert type(input_initial[0][1]) == str
    assert len(dependencies_iteration1) == 0
    assert len(dependencies_iteration2) == 0
    assert len(dependencies_iteration3) == 1
    assert len(dependencies_iteration4) == 1
    assert len(dependencies_iteration5) == 3
    assert len(dependencies_iteration6) == 4
    assert type(dependencies_iteration4[0]) == tuple
    assert type(dependencies_iteration4[0][0]) == int
    assert type(dependencies_iteration4[0][1]) == int

@test_case(points=0.5, hidden=True)
def test_pen_and_paper_input_initial(input_initial, input_iteration1, input_iteration2, input_iteration3, input_iteration4, input_iteration5, input_iteration6, dependencies_iteration1, dependencies_iteration2, dependencies_iteration3, dependencies_iteration4, dependencies_iteration5, dependencies_iteration6, stack_intial, stack_iteration1, stack_iteration2, stack_iteration3, stack_iteration4, stack_iteration5, stack_iteration6):
    assert input_initial == [(1, '('), (2, '('), (3, ')'), (4, ')')]

@test_case(points=0.5, hidden=True)
def test_pen_and_paper_input_1(input_initial, input_iteration1, input_iteration2, input_iteration3, input_iteration4, input_iteration5, input_iteration6, dependencies_iteration1, dependencies_iteration2, dependencies_iteration3, dependencies_iteration4, dependencies_iteration5, dependencies_iteration6, stack_intial, stack_iteration1, stack_iteration2, stack_iteration3, stack_iteration4, stack_iteration5, stack_iteration6):
    assert input_iteration1 == [(2, '('), (3, ')'), (4, ')')]

@test_case(points=0.5, hidden=True)
def test_pen_and_paper_input_2(input_initial, input_iteration1, input_iteration2, input_iteration3, input_iteration4, input_iteration5, input_iteration6, dependencies_iteration1, dependencies_iteration2, dependencies_iteration3, dependencies_iteration4, dependencies_iteration5, dependencies_iteration6, stack_intial, stack_iteration1, stack_iteration2, stack_iteration3, stack_iteration4, stack_iteration5, stack_iteration6):
    assert input_iteration2 == [(3, ')'), (4, ')')]

@test_case(points=1, hidden=True)
def test_pen_and_paper_input_3(input_initial, input_iteration1, input_iteration2, input_iteration3, input_iteration4, input_iteration5, input_iteration6, dependencies_iteration1, dependencies_iteration2, dependencies_iteration3, dependencies_iteration4, dependencies_iteration5, dependencies_iteration6, stack_intial, stack_iteration1, stack_iteration2, stack_iteration3, stack_iteration4, stack_iteration5, stack_iteration6):
    assert input_iteration3 == [(3, 'X'), (4, ')')]

@test_case(points=0.5, hidden=True)
def test_pen_and_paper_input_4(input_initial, input_iteration1, input_iteration2, input_iteration3, input_iteration4, input_iteration5, input_iteration6, dependencies_iteration1, dependencies_iteration2, dependencies_iteration3, dependencies_iteration4, dependencies_iteration5, dependencies_iteration6, stack_intial, stack_iteration1, stack_iteration2, stack_iteration3, stack_iteration4, stack_iteration5, stack_iteration6):
    assert input_iteration4 == [(4, ')')]

@test_case(points=0.5, hidden=True)
def test_pen_and_paper_stack_1(input_initial, input_iteration1, input_iteration2, input_iteration3, input_iteration4, input_iteration5, input_iteration6, dependencies_iteration1, dependencies_iteration2, dependencies_iteration3, dependencies_iteration4, dependencies_iteration5, dependencies_iteration6, stack_intial, stack_iteration1, stack_iteration2, stack_iteration3, stack_iteration4, stack_iteration5, stack_iteration6):
    assert stack_iteration1 == [(0, 'X'), (1, '(')]

@test_case(points=0.5, hidden=True)
def test_pen_and_paper_stack_2(input_initial, input_iteration1, input_iteration2, input_iteration3, input_iteration4, input_iteration5, input_iteration6, dependencies_iteration1, dependencies_iteration2, dependencies_iteration3, dependencies_iteration4, dependencies_iteration5, dependencies_iteration6, stack_intial, stack_iteration1, stack_iteration2, stack_iteration3, stack_iteration4, stack_iteration5, stack_iteration6):
    assert stack_iteration2 == [(0, 'X'), (1, '('), (2, '(')]

@test_case(points=1, hidden=True)
def test_pen_and_paper_stack_3(input_initial, input_iteration1, input_iteration2, input_iteration3, input_iteration4, input_iteration5, input_iteration6, dependencies_iteration1, dependencies_iteration2, dependencies_iteration3, dependencies_iteration4, dependencies_iteration5, dependencies_iteration6, stack_intial, stack_iteration1, stack_iteration2, stack_iteration3, stack_iteration4, stack_iteration5, stack_iteration6):
    assert stack_iteration3 == [(0, 'X'), (1, '(')]

@test_case(points=0.5, hidden=True)
def test_pen_and_paper_stack_4(input_initial, input_iteration1, input_iteration2, input_iteration3, input_iteration4, input_iteration5, input_iteration6, dependencies_iteration1, dependencies_iteration2, dependencies_iteration3, dependencies_iteration4, dependencies_iteration5, dependencies_iteration6, stack_intial, stack_iteration1, stack_iteration2, stack_iteration3, stack_iteration4, stack_iteration5, stack_iteration6):
    assert stack_iteration4 == [(0, 'X'), (1, '('), (3, 'X')]

@test_case(points=1, hidden=True)
def test_pen_and_paper_stack_5(input_initial, input_iteration1, input_iteration2, input_iteration3, input_iteration4, input_iteration5, input_iteration6, dependencies_iteration1, dependencies_iteration2, dependencies_iteration3, dependencies_iteration4, dependencies_iteration5, dependencies_iteration6, stack_intial, stack_iteration1, stack_iteration2, stack_iteration3, stack_iteration4, stack_iteration5, stack_iteration6):
    assert stack_iteration5 == [(0, 'X')]

@test_case(points=0.5, hidden=True)
def test_pen_and_paper_stack_6(input_initial, input_iteration1, input_iteration2, input_iteration3, input_iteration4, input_iteration5, input_iteration6, dependencies_iteration1, dependencies_iteration2, dependencies_iteration3, dependencies_iteration4, dependencies_iteration5, dependencies_iteration6, stack_intial, stack_iteration1, stack_iteration2, stack_iteration3, stack_iteration4, stack_iteration5, stack_iteration6):
    assert stack_iteration6 == []

@test_case(points=1, hidden=True)
def test_pen_and_paper_dependencies_3(input_initial, input_iteration1, input_iteration2, input_iteration3, input_iteration4, input_iteration5, input_iteration6, dependencies_iteration1, dependencies_iteration2, dependencies_iteration3, dependencies_iteration4, dependencies_iteration5, dependencies_iteration6, stack_intial, stack_iteration1, stack_iteration2, stack_iteration3, stack_iteration4, stack_iteration5, stack_iteration6):
    assert set(dependencies_iteration3) == set([(2, 3)])

@test_case(points=1, hidden=True)
def test_pen_and_paper_dependencies_4(input_initial, input_iteration1, input_iteration2, input_iteration3, input_iteration4, input_iteration5, input_iteration6, dependencies_iteration1, dependencies_iteration2, dependencies_iteration3, dependencies_iteration4, dependencies_iteration5, dependencies_iteration6, stack_intial, stack_iteration1, stack_iteration2, stack_iteration3, stack_iteration4, stack_iteration5, stack_iteration6):
    assert set(dependencies_iteration4) == set([(2, 3)])

@test_case(points=1, hidden=True)
def test_pen_and_paper_dependencies_5(input_initial, input_iteration1, input_iteration2, input_iteration3, input_iteration4, input_iteration5, input_iteration6, dependencies_iteration1, dependencies_iteration2, dependencies_iteration3, dependencies_iteration4, dependencies_iteration5, dependencies_iteration6, stack_intial, stack_iteration1, stack_iteration2, stack_iteration3, stack_iteration4, stack_iteration5, stack_iteration6):
    assert set(dependencies_iteration5) == set([(2, 3), (1, 4), (3, 4)])

