from otter.test_files import test_case

OK_FORMAT = False

name = "q3b"
points = 10

@test_case(points=2.5, hidden=False)
def test_vectoriser_basic(vectoriser):
    from sklearn.feature_extraction import DictVectorizer
    assert isinstance(vectoriser, DictVectorizer) == True
    assert hasattr(vectoriser, 'feature_names_') == True
    assert len(vectoriser.feature_names_) > 0

@test_case(points=2, hidden=True)
def test_vectoriser_advanced(vectoriser):
    assert len(vectoriser.feature_names_) >= 50000
    assert len(vectoriser.feature_names_) <= 60000

@test_case(points=2, hidden=True)
def test_features_advanced(vectoriser, train_features):
    n_rows = 391798
    n_feats = len(vectoriser.feature_names_)
    assert train_features.shape == (n_rows, n_feats)

@test_case(points=2.5, hidden=False)
def test_classifier_basic(classifier):
    from sklearn.linear_model import LogisticRegression
    assert isinstance(classifier, LogisticRegression) == True
    assert hasattr(classifier, 'classes_') == True

@test_case(points=1, hidden=True)
def test_classifier_advanced(classifier, vectoriser):
    assert len(classifier.classes_) == 4
    assert classifier.coef_.shape == (4, len(vectoriser.feature_names_))

