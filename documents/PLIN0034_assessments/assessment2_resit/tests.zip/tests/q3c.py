from otter.test_files import test_case

OK_FORMAT = False

name = "q3c"
points = 6

@test_case(points=2, hidden=False)
def test_train_accuracy_basic(train_accuracy):
    if train_accuracy < 1:
        train_accuracy *= 100
    assert train_accuracy < 100
    assert train_accuracy > 1

@test_case(points=4, hidden=True)
def test_train_accuracy_advanced(train_accuracy):
    if train_accuracy < 1:
        train_accuracy *= 100
    assert train_accuracy < 96
    assert train_accuracy > 85

