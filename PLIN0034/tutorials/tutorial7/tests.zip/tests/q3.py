from otter.test_files import test_case

OK_FORMAT = False

name = "q3"
points = None

def format_error(lines, line, ret_value="", fn_name=""):
    return_str = "\n\n"
    return_str += "The last line of the following test program failed.\n"
    return_str += "Make sure that your function returns exactly the same value\n"
    return_str += "as specified in the <b>assert</b> statement.\n\n"

    num_spaces = len(lines[2]) - len(lines[2].strip()) 
    return_str += "\n".join([l[num_spaces:].strip() for l in lines[2:line+1]])
    return_str += "\n<b>"
    return_str += lines[line+1][num_spaces:]
    return_str += "</b>\n\n"

    return_str += f"{fn_name} returned:\n"
    return_str += str(ret_value)
    return_str += "\n\n"

    return return_str  




def test_classifier_desc(line, ret_value, fn_name):
    test_strs = '''
def test_classifier(classifier, vectoriser):
    ex1 = {'drama': 1, 'is': 1, 'gripping': 1}
    ex2 = {'movie': 1, 'is': 1, 'hilarious': 1}
    ex3 = {'one': 1, 'learns': 1, 'so': 1, 'much': 1, 'about': 1, 'world': 1, 'war': 1}
    feats = vectoriser.transform([ex1, ex2, ex3])
    preds = classifier.predict(feats)
    gold = ['drama', 'comedy', 'documentary']
    for i in range(len(preds)):
        assert preds[i] == gold[i]
    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)


@test_case(points=None, hidden=False)
def test_classifier(classifier, vectoriser):
    ex1 = {'drama': 1, 'is': 1, 'gripping': 1}
    ex2 = {'movie': 1, 'is': 1, 'hilarious': 1}
    ex3 = {'one': 1, 'learns': 1, 'so': 1, 'much': 1, 'about': 1, 'world': 1, 'war': 1}
    feats = vectoriser.transform([ex1, ex2, ex3])
    preds = classifier.predict(feats)
    gold = ['drama', 'comedy', 'documentary']
    for i in range(len(preds)):
        assert preds[i] == gold[i], test_classifier_desc(8, preds[i], "preds[i]")

