from otter.test_files import test_case

OK_FORMAT = False

name = "q4"
points = None

def format_error(lines, line, ret_value="", fn_name=""):
    return_str = "\n\n"
    return_str += "The last line of the following test program failed.\n"
    return_str += "Make sure that your function returns exactly the same value\n"
    return_str += "as specified in the <b>assert</b> statement.\n\n"

    num_spaces = len(lines[2]) - len(lines[2].strip()) 
    return_str += "\n".join([l[num_spaces:].strip() for l in lines[2:line+1]])
    return_str += "\n<b>"
    return_str += lines[line+1][num_spaces:]
    return_str += "</b>\n\n"

    return_str += f"{fn_name} returned:\n"
    return_str += str(ret_value)
    return_str += "\n\n"

    return return_str  




def test_acc_computation_desc(line, ret_value, fn_name):
    test_strs = '''
def test_acc_computation(test_features, test_accuracy):
    assert test_features.shape == (54200, 148214)
    if test_accuracy < 1:
        test_accuracy *= 100
    assert test_accuracy >= 55
    assert test_accuracy <= 60
    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)


@test_case(points=None, hidden=False)
def test_acc_computation(test_features, test_accuracy):
    assert test_features.shape == (54200, 148214), test_acc_computation_desc(1, test_features.shape, "test_features.shape")
    if test_accuracy < 1:
        test_accuracy *= 100
    assert test_accuracy >= 55, test_acc_computation_desc(4, test_accuracy, "test_accuracy")
    assert test_accuracy <= 60, test_acc_computation_desc(5, test_accuracy, "test_accuracy")

