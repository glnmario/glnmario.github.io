from otter.test_files import test_case

OK_FORMAT = False

name = "q1"
points = None

def format_error(lines, line, ret_value="", fn_name=""):
    return_str = "\n\n"
    return_str += "The last line of the following test program failed.\n"
    return_str += "Make sure that your function returns exactly the same value\n"
    return_str += "as specified in the <b>assert</b> statement.\n\n"

    num_spaces = len(lines[2]) - len(lines[2].strip()) 
    return_str += "\n".join([l[num_spaces:].strip() for l in lines[2:line+1]])
    return_str += "\n<b>"
    return_str += lines[line+1][num_spaces:]
    return_str += "</b>\n\n"

    return_str += f"{fn_name} returned:\n"
    return_str += str(ret_value)
    return_str += "\n\n"

    return return_str  




def test_extract_features_desc(line, ret_value, fn_name):
    test_strs = '''
def test_extract_features(extract_features, train_data):
    sample_feature_dicts, sample_labels = extract_features(train_data.head(10))
    assert len(sample_feature_dicts) == 10
    assert len(sample_labels) == 10
    assert sample_labels[:3] == ['drama', 'thriller', 'adult']
    ex_1_words = ['listening', 'in', 'to', 'a', 'conversation']
    for w in ex_1_words:
        assert (w in sample_feature_dicts[0]) == True
    num_entries = len(sample_feature_dicts[0])
    assert sum(sample_feature_dicts[0].values()) == num_entries
    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)


@test_case(points=None, hidden=False)
def test_extract_features(extract_features, train_data):
    sample_feature_dicts, sample_labels = extract_features(train_data.head(10))
    assert len(sample_feature_dicts) == 10, test_extract_features_desc(2, len(sample_feature_dicts), "len(sample_feature_dicts)")
    assert len(sample_labels) == 10, test_extract_features_desc(3, len(sample_labels), "len(sample_labels)")
    assert sample_labels[:3] == ['drama', 'thriller', 'adult'], test_extract_features_desc(4, sample_labels[:3], "sample_labels[:3]")
    ex_1_words = ['listening', 'in', 'to', 'a', 'conversation']
    for w in ex_1_words:
        assert (w in sample_feature_dicts[0]) == True, test_extract_features_desc(7, (w in sample_feature_dicts[0]), "(w in sample_feature_dicts[0])")
    num_entries = len(sample_feature_dicts[0])
    assert sum(sample_feature_dicts[0].values()) == num_entries, test_extract_features_desc(9, sum(sample_feature_dicts[0].values()), "sum(sample_feature_dicts[0].values())")

