from otter.test_files import test_case

OK_FORMAT = False

name = "q2"
points = None

def format_error(lines, line, ret_value="", fn_name=""):
  return_str = "\n\n"
  return_str += "The last line of the following test program failed.\n"
  return_str += "Make sure that your function returns exactly the same value\n"
  return_str += "as specified in the <b>assert</b> statement.\n\n"
  
  return_str += "\n".join([l.strip() for l in lines[2:line+1]])
  return_str += "\n<b>"
  return_str += lines[line+1]
  return_str += "</b>\n\n"
  
  return_str += f"{fn_name} returned:\n"
  return_str += str(ret_value)
  return_str += "\n\n"
  
  return return_str  
 


def test_make_table_desc(line, ret_value, fn_name):
    test_strs = '''
def test_make_table(make_table):
  assert make_table(2,3) == [[0, 0, 0], [0, 0, 0]]
  assert make_table(7,5) == [[0, 0, 0, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0]]
  assert make_table(5,7) == [[0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0]]
  assert make_table(2,0) == [[], []]
  assert make_table(0,2) == []

    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)

@test_case(points=None, hidden=False)
def test_make_table(make_table):
  assert make_table(2,3) == [[0, 0, 0], [0, 0, 0]], test_make_table_desc(1, make_table(2,3), "make_table(2,3)")
  assert make_table(7,5) == [[0, 0, 0, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0]], test_make_table_desc(2, make_table(7,5), "make_table(7,5)")
  assert make_table(5,7) == [[0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0]], test_make_table_desc(3, make_table(5,7), "make_table(5,7)")
  assert make_table(2,0) == [[], []], test_make_table_desc(4, make_table(2,0), "make_table(2,0)")
  assert make_table(0,2) == [], test_make_table_desc(5, make_table(0,2), "make_table(0,2)")

