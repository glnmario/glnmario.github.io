from otter.test_files import test_case

OK_FORMAT = False

name = "q1"
points = None

def format_error(lines, line, ret_value="", fn_name=""):
  return_str = "\n\n"
  return_str += "The last line of the following test program failed.\n"
  return_str += "Make sure that your function returns exactly the same value\n"
  return_str += "as specified in the <b>assert</b> statement.\n\n"
  
  num_spaces = len(lines[2]) - len(lines[2].strip()) 
  return_str += "\n".join([l[num_spaces:].strip() for l in lines[2:line+1]])
  return_str += "\n<b>"
  return_str += lines[line+1][num_spaces:]
  return_str += "</b>\n\n"
  
  return_str += f"{fn_name} returned:\n"
  return_str += str(ret_value)
  return_str += "\n\n"
  
  return return_str  

                                            


@test_case(points=None, hidden=False)
def test_1abc(ans_1a, ans_1b, ans_1c):
  GOLD = {"1a": 1/3, "1b": 2/3, "1c": 1/2}




  assert ans_1a > GOLD["1a"] - 0.01, "The answer to exercise '1a' is not correct"
  assert ans_1a < GOLD["1a"] + 0.01, "The answer to exercise '1a' is not correct"
  assert ans_1b > GOLD["1b"] - 0.01, "The answer to exercise '1b' is not correct"
  assert ans_1b < GOLD["1b"] + 0.01, "The answer to exercise '1b' is not correct"
  assert ans_1c > GOLD["1c"] - 0.01, "The answer to exercise '1c' is not correct"
  assert ans_1c < GOLD["1c"] + 0.01, "The answer to exercise '1c' is not correct"




@test_case(points=None, hidden=False)
def test_1def(ans_1d, ans_1e, ans_1f):
  GOLD = {"1d": 0.5**3, "1e": 3 * 0.5**3, "1f": 1 - 0.5**3}




  assert ans_1d > GOLD["1d"] - 0.01, "The answer to exercise '1d' is not correct"
  assert ans_1d < GOLD["1d"] + 0.01, "The answer to exercise '1d' is not correct"
  assert ans_1e > GOLD["1e"] - 0.01, "The answer to exercise '1e' is not correct"
  assert ans_1e < GOLD["1e"] + 0.01, "The answer to exercise '1e' is not correct"
  assert ans_1f > GOLD["1f"] - 0.01, "The answer to exercise '1f' is not correct"
  assert ans_1f < GOLD["1f"] + 0.01, "The answer to exercise '1f' is not correct"



@test_case(points=None, hidden=False)
def test_1ghij(ans_1g, ans_1h, ans_1i, ans_1j):
    GOLD = {"1g1":  1814 / (1814 + 600 + 220 + 629),
            "1g2": 220 / (1814 + 600 + 220 + 629),
            "1g3": 600 / (1814 + 600 + 220 + 629),
            "1g4": 629 / (1814 + 600 + 220 + 629),
            "1h": (1814+220) / (1814 + 600 + 220 + 629),
            "1i": (1814+600) / (1814 + 600 + 220 + 629),
            "1j": 1814 / (1814 + 220)}



    assert ans_1g["pronoun"]["DO"] > GOLD["1g1"] - 0.01, "The answer to exercise '1g' is not correct"
    assert ans_1g["pronoun"]["PO"] > GOLD["1g2"] - 0.01, "The answer to exercise '1g' is not correct"
    assert ans_1g["not-pronoun"]["DO"] > GOLD["1g3"] - 0.01, "The answer to exercise '1g' is not correct"
    assert ans_1g["not-pronoun"]["PO"] > GOLD["1g4"] - 0.01, "The answer to exercise '1g' is not correct"
    assert ans_1g["pronoun"]["DO"] < GOLD["1g1"] + 0.01, "The answer to exercise '1g' is not correct"
    assert ans_1g["pronoun"]["PO"] < GOLD["1g2"] + 0.01, "The answer to exercise '1g' is not correct"
    assert ans_1g["not-pronoun"]["DO"] < GOLD["1g3"] + 0.01, "The answer to exercise '1g' is not correct"
    assert ans_1g["not-pronoun"]["PO"] < GOLD["1g4"] + 0.01, "The answer to exercise '1g' is not correct"

    assert ans_1h > GOLD["1h"] - 0.01, "The answer to exercise '1h' is not correct"
    assert ans_1h < GOLD["1h"] + 0.01, "The answer to exercise '1h' is not correct"

    assert ans_1i > GOLD["1i"] - 0.01, "The answer to exercise '1i' is not correct"
    assert ans_1i < GOLD["1i"] + 0.01, "The answer to exercise '1i' is not correct"

    assert ans_1j > GOLD["1j"] - 0.01, "The answer to exercise '1j' is not correct"
    assert ans_1j < GOLD["1j"] + 0.01, "The answer to exercise '1j' is not correct"

