from otter.test_files import test_case

OK_FORMAT = False

name = "q2b"
points = 10

def format_error(lines, line, ret_value="", fn_name=""):
  return_str = "\n\n"
  return_str += "The last line of the following test program failed.\n"
  return_str += "Make sure that your function returns exactly the same value\n"
  return_str += "as specified in the <b>assert</b> statement.\n\n"
  
  num_spaces = len(lines[2]) - len(lines[2].strip()) 
  return_str += "\n".join([l[num_spaces:].strip() for l in lines[2:line+1]])
  return_str += "\n<b>"
  return_str += lines[line+1][num_spaces:]
  return_str += "</b>\n\n"
  
  return_str += f"{fn_name} returned:\n"
  return_str += str(ret_value)
  return_str += "\n\n"
  
  return return_str  

                                            


def tokenise_test_basic_desc(line, ret_value, fn_name):
    test_strs = '''

def tokenise_test_basic(tokenise):
  s = "bayes' theorem is named after the reverend thomas bayes (/beɪz/), ph.d., also a statistician and philosopher."
  words = tokenise(s)
  expected_words = ['bayes', 'theorem', 'is', 'named', 'after', 'the', 'reverend', 'thomas', 'bayes', '/beɪz/', 'ph.d.', 'also', 'a', 'statistician', 'and', 'philosopher']
  assert words == expected_words


  s = "the cat sat on the mat."
  words = tokenise(s)
  expected_words = ['the', 'cat', 'sat', 'on', 'the', 'mat']
  assert words == expected_words

    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)

@test_case(points=5, hidden=False)

def tokenise_test_basic(tokenise):
  s = "bayes' theorem is named after the reverend thomas bayes (/beɪz/), ph.d., also a statistician and philosopher."
  words = tokenise(s)
  expected_words = ['bayes', 'theorem', 'is', 'named', 'after', 'the', 'reverend', 'thomas', 'bayes', '/beɪz/', 'ph.d.', 'also', 'a', 'statistician', 'and', 'philosopher']
  assert words == expected_words, tokenise_test_basic_desc(5, words, "words")


  s = "the cat sat on the mat."
  words = tokenise(s)
  expected_words = ['the', 'cat', 'sat', 'on', 'the', 'mat']
  assert words == expected_words, tokenise_test_basic_desc(11, words, "words")

